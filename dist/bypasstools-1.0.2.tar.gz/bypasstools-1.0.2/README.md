# bypasstools

Official Python SDK for the [BypassTools](https://bypass.tools) API.

## Installation

```bash
pip install bypasstools
```

## Quick Start

```python
from bypasstools import BypassTools

client = BypassTools(api_key="bt_your_key_here")

# Direct (synchronous) bypass
result = client.bypass("https://linkvertise.com/example")
print(result.result_url)

# Async task — create and poll until done
result = client.bypass_async("https://loot.link/example")
print(result.result_url)
```

## Authentication

Get your API key from your [dashboard](https://bypass.tools/dashboard/keys).

## Methods

### `bypass(url, *, refresh=False) -> BypassResult`
Calls the direct bypass endpoint and blocks until a result is returned.

### `create_task(url) -> str`
Creates an async task and returns the `taskId`.

### `get_task_result(task_id) -> TaskResult`
Polls a single task for its current status.

### `bypass_async(url, *, poll_interval=1.5, timeout=90) -> BypassResult`
Creates a task and polls until it completes or times out.

## Async Usage

Requires `aiohttp`:

```bash
pip install bypasstools aiohttp
```

```python
import asyncio
from bypasstools import AsyncBypassTools

async def main():
    client = AsyncBypassTools(api_key="bt_your_key_here")
    result = await client.bypass("https://linkvertise.com/example")
    print(result.result_url)

asyncio.run(main())
```

## Error Handling

```python
from bypasstools import BypassTools, BypassToolsError

client = BypassTools(api_key="bt_your_key_here")

try:
    result = client.bypass("https://linkvertise.com/example")
except BypassToolsError as e:
    print(e.code)    # e.g. "QUOTA_EXCEEDED"
    print(e.status)  # HTTP status code
    print(str(e))    # error message
```

## License

MIT
